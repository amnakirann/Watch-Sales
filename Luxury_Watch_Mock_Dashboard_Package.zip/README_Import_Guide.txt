Luxury Watch Mock Dashboard – Import Guide

Files in this package:
- KPI_*.png: Place on the Overview page (top row).
- Revenue_by_Brand_Top12.png: Column chart for brand revenue.
- Market_Share_by_Country.png: Pie chart for revenue share by country.
- Price_vs_Rating_Bubble.png: Scatter/bubble chart.
- Revenue_Trend_by_Year.png: Line chart for revenue over time.
- Units_Sold_by_Model_Top10.png: Top models by units.
- Price_Distribution_by_Brand.png: Boxplot of prices by brand.
- Heatmap_DialColor_vs_StrapMaterial.png: Popularity heatmap (counts).
- Warranty_Impact_on_Units.png: Units by warranty years.
- Brand_Model_Matrix.csv: Table you can import as a separate dataset for a matrix visual.
- powerbi_theme_luxury_dark_gold.json: Import this theme in Power BI (View > Themes > Browse for themes).

Suggested Page Layouts (match the earlier plan):
1) Executive Overview
   - KPI_*.png on top
   - Revenue_by_Brand_Top12.png (left), Market_Share_by_Country.png (right)
   - Revenue_Trend_by_Year.png (full width bottom)

2) Brand & Model Performance
   - Units_Sold_by_Model_Top10.png (left)
   - Price_Distribution_by_Brand.png (right)
   - Import Brand_Model_Matrix.csv as a table

3) Price & Rating Analysis
   - Price_vs_Rating_Bubble.png (full width)
   - Heatmap_DialColor_vs_StrapMaterial.png (bottom)

4) Time & Sales Trends
   - Revenue_Trend_by_Year.png (left)
   - Warranty_Impact_on_Units.png (right)

Tips:
- Use your original 10k CSV as the primary dataset in Power BI for slicers/filters.
- Set theme via View > Themes > Browse and select powerbi_theme_luxury_dark_gold.json.
- Insert > Image to place the PNGs; adjust size to fit canvas.
